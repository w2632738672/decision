import csv
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn import tree

content1 = pd.read_csv('train.csv')
x_train = content1[['service_type','is_mix_service','online_time','1_total_fee','month_traffic','many_over_bill','contract_type','contract_time','is_promise_low_consume','net_service','pay_times','pay_num','last_month_traffic','local_trafffic_month','local_caller_time','service1_caller_time','service2_caller_time','complaint_level','former_complaint_num','former_complaint_fee']]
y_train = content1['current_service']
content2 = pd.read_csv('test.csv')
x_test = content2[['service_type','is_mix_service','online_time','1_total_fee','month_traffic','many_over_bill','contract_type','contract_time','is_promise_low_consume','net_service','pay_times','pay_num','last_month_traffic','local_trafffic_month','local_caller_time','service1_caller_time','service2_caller_time','complaint_level','former_complaint_num','former_complaint_fee']]
y_test = content2['current_service']

clf = tree.DecisionTreeClassifier(criterion="entropy",max_depth=26,min_samples_split=2,min_samples_leaf=2, max_leaf_nodes=100000)  # 载入决策树分类模型

clf = clf.fit(x_train, y_train)  # 决策树拟合，得到模型

score = clf.score(x_test, y_test)  # 返回预测的准确度
#print('预测正确率为：', score*100, '%')
predictedY=clf.predict(x_test)
file = csv.reader(open('test.csv', 'r'))

final_list = []
i = 0
zero = 0

for line in file:
    if zero == 0:
        zero += 1
        continue
    temp = [line[26], predictedY[i]]
    i += 1
    final_list.append(temp)
name = ['user_id', 'current_service']
save_file = pd.DataFrame(columns=name, data=final_list)
save_file.to_csv('submit_sample.csv', index=False)


